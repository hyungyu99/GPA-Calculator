package android.example.gpacalculator;

import android.annotation.SuppressLint;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText grade1;
    private EditText grade2;
    private EditText grade3;
    private EditText grade4;
    private EditText grade5;

    private TextView gpa;

    private View parentView;

    private Button calculateButton;

    private boolean isCalculated;
    private double averageGrade;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        grade1 = findViewById(R.id.grade1_editText);
        grade2 = findViewById(R.id.grade2_editText);
        grade3 = findViewById(R.id.grade3_editText);
        grade4 = findViewById(R.id.grade4_editText);
        grade5 = findViewById(R.id.grade5_editText);
        gpa = findViewById(R.id.gpa_textView);
        parentView = findViewById(R.id.parent);

        gpa.setText("0");
        calculateButton = findViewById(R.id.calculate_button);
        clearFields();
        calculateButton.setOnClickListener(v -> {
            if (!isCalculated) {
                if (!isClear()) {
                    double grade = 0;
                    grade += Integer.parseInt(grade1.getText().toString().trim());
                    grade += Integer.parseInt(grade2.getText().toString().trim());
                    grade += Integer.parseInt(grade3.getText().toString().trim());
                    grade += Integer.parseInt(grade4.getText().toString().trim());
                    grade += Integer.parseInt(grade5.getText().toString().trim());

                    averageGrade = grade / 5.0;
                    @SuppressLint("DefaultLocale") String text = String.format("%.2f", averageGrade);
                    gpa.setText(text);
                    setBackGroundColor(averageGrade);
                    calculateButton.setText("Clear");
                    isCalculated = true;
                }else {
                    Toast.makeText(MainActivity.this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                }
            }else {
                clearFields();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    parentView.setBackgroundColor(getColor(R.color.white));
                }
                gpa.setText("0");
                calculateButton.setText("Compute GPA");
                isCalculated = false;
            }
        });
    }

    private void setBackGroundColor(double grade) {
        if (grade < 60) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                parentView.setBackgroundColor(getColor(R.color.red));
            }
        } else if (grade >= 60 && grade < 80) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                parentView.setBackgroundColor(getColor(R.color.yellow));
            }
        } else if (grade >= 80 && grade <= 100) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                parentView.setBackgroundColor(getColor(R.color.green));
            }
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                parentView.setBackgroundColor(getColor(R.color.white));
            }
        }
    }

    private boolean isClear() {
        return grade1.getText().toString().trim().equals("") || grade2.getText().toString().trim().equals("") ||
                grade3.getText().toString().trim().equals("") || grade4.getText().toString().trim().equals("") ||
                grade5.getText().toString().trim().equals("");
    }

    private void clearFields() {
        grade1.setText("");
        grade2.setText("");
        grade3.setText("");
        grade4.setText("");
        grade5.setText("");
    }

}
